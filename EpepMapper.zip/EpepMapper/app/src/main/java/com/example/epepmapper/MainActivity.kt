package com.example.epepmapper

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
        }
        col.addView(TextView(this).apply {
            text = "1. Aktifkan 'Epep Mapper' di Aksesibilitas.\n" +
                "2. Sambungkan keyboard dan mouse (OTG/Bluetooth).\n" +
                "3. Buka game. WASD = gerak, klik kiri = tembak, klik kanan = scope, mouse = kamera."
        })
        col.addView(Button(this).apply {
            text = "Buka pengaturan aksesibilitas"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        col.addView(TextView(this).apply { text = "Sensitivitas mouse" })
        col.addView(SeekBar(this).apply {
            max = 100
            progress = prefs.getInt("sens", 30)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, user: Boolean) { prefs.edit().putInt("sens", p).apply() }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        })
        setContentView(col)
    }
}
