package com.example.epepmapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PointF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.hypot

private const val TICK = 40L // ms per potongan gestur

class MapperService : AccessibilityService() {
    private class Finger(var stroke: GestureDescription.StrokeDescription? = null, var cur: PointF = PointF())

    private val fingers = HashMap<Int, Finger>()
    private val pressed = HashSet<Int>()
    private val handler = Handler(Looper.getMainLooper())
    private var dx = 0f
    private var dy = 0f
    private var lastX = Float.NaN
    private var lastY = Float.NaN
    private var running = false

    override fun onServiceConnected() {
        serviceInfo = serviceInfo.apply {
            if (Build.VERSION.SDK_INT >= 34) motionEventSources = InputDevice.SOURCE_MOUSE
        }
    }

    override fun onKeyEvent(e: KeyEvent): Boolean {
        val k = e.keyCode
        if (k !in Layout.buttons && k !in MOVE) return false // tombol lain lewat seperti biasa
        if (e.action == KeyEvent.ACTION_DOWN) pressed.add(k) else if (e.action == KeyEvent.ACTION_UP) pressed.remove(k)
        start()
        return true
    }

    // Hanya dipanggil di Android 14+ (API 34)
    override fun onMotionEvent(event: MotionEvent) {
        if ((event.source and InputDevice.SOURCE_MOUSE) != InputDevice.SOURCE_MOUSE) return
        when (event.actionMasked) {
            MotionEvent.ACTION_HOVER_MOVE, MotionEvent.ACTION_MOVE -> {
                if (!lastX.isNaN()) { dx += event.x - lastX; dy += event.y - lastY }
                lastX = event.x; lastY = event.y
            }
            MotionEvent.ACTION_BUTTON_PRESS -> button(event, true)
            MotionEvent.ACTION_BUTTON_RELEASE -> button(event, false)
        }
        start()
    }

    private fun button(e: MotionEvent, down: Boolean) {
        val c = if (e.actionButton == MotionEvent.BUTTON_SECONDARY) SCOPE else FIRE
        if (down) pressed.add(c) else pressed.remove(c)
    }

    private fun start() { if (!running) { running = true; tick() } }

    // Satu gestur = semua jari sekaligus, karena dispatchGesture membatalkan gestur lain yang sedang jalan.
    private fun tick() {
        val b = getSystemService(WindowManager::class.java).currentWindowMetrics.bounds
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        fun px(p: Pair<Float, Float>) = PointF(p.first * w, p.second * h)

        val want = HashMap<Int, PointF>() // posisi tujuan jari; tidak ada = jari diangkat
        val home = HashMap<Int, PointF>() // posisi awal jari baru
        for (k in pressed) Layout.buttons[k]?.let { want[k] = px(it); home[k] = px(it) }

        val c = px(Layout.joystick)
        home[JOY] = c
        val ax = (if (KeyEvent.KEYCODE_D in pressed) 1 else 0) - (if (KeyEvent.KEYCODE_A in pressed) 1 else 0)
        val ay = (if (KeyEvent.KEYCODE_S in pressed) 1 else 0) - (if (KeyEvent.KEYCODE_W in pressed) 1 else 0)
        if (ax != 0 || ay != 0) {
            val l = hypot(ax.toFloat(), ay.toFloat())
            val r = Layout.JOY_RADIUS * h
            want[JOY] = PointF(c.x + ax / l * r, c.y + ay / l * r)
        }

        val sens = getSharedPreferences("cfg", MODE_PRIVATE).getInt("sens", 30) / 10f
        val mx = dx * sens
        val my = dy * sens
        dx = 0f; dy = 0f
        val camHome = px(Layout.camera)
        home[CAM] = camHome
        if (mx != 0f || my != 0f) {
            val from = fingers[CAM]?.takeIf { it.stroke != null }?.cur ?: camHome
            val tx = from.x + mx
            val ty = from.y + my
            // keluar layar -> jari diangkat, geseran berikutnya mulai lagi dari titik awal
            if (tx in 0f..w && ty in 0f..h) want[CAM] = PointF(tx, ty)
        }

        val g = GestureDescription.Builder()
        var n = 0
        for (id in (fingers.keys + want.keys).toSet()) {
            val f = fingers.getOrPut(id) { Finger() }
            val t = want[id]
            if (t == null && f.stroke == null) { fingers.remove(id); continue }
            val from = if (f.stroke == null) home[id]!! else f.cur
            val to = t ?: from
            val p = Path().apply {
                moveTo(from.x, from.y)
                if (to.x != from.x || to.y != from.y) lineTo(to.x, to.y)
            }
            val s = f.stroke?.continueStroke(p, 0, TICK, t != null)
                ?: GestureDescription.StrokeDescription(p, 0, TICK, t != null)
            f.stroke = if (t != null) s else null
            f.cur = to
            g.addStroke(s)
            n++
        }
        if (n == 0) { running = false; return }

        val ok = dispatchGesture(g.build(), object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { tick() }
            override fun onCancelled(d: GestureDescription?) { fingers.clear(); handler.postDelayed({ tick() }, 50) }
        }, null)
        if (!ok) { fingers.clear(); running = false }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    companion object {
        private val MOVE = setOf(KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D)
    }
}
