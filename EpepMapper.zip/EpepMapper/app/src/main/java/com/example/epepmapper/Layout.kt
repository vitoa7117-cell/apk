package com.example.epepmapper

import android.view.KeyEvent

const val FIRE = -1   // klik kiri mouse
const val SCOPE = -2  // klik kanan mouse
const val JOY = -10   // jari virtual untuk joystick
const val CAM = -11   // jari virtual untuk kamera

// Semua posisi = pecahan layar (x, y), layar landscape.
// Ubah angkanya supaya pas dengan posisi tombol di HUD Free Fire-mu.
object Layout {
    val joystick = 0.14f to 0.70f
    const val JOY_RADIUS = 0.10f // pecahan tinggi layar
    val camera = 0.70f to 0.45f  // titik awal geseran kamera

    val buttons = mapOf(
        FIRE to (0.85f to 0.45f),
        SCOPE to (0.80f to 0.30f),
        KeyEvent.KEYCODE_SPACE to (0.90f to 0.62f), // lompat
        KeyEvent.KEYCODE_R to (0.78f to 0.80f),     // reload
        KeyEvent.KEYCODE_C to (0.93f to 0.80f),     // jongkok
        KeyEvent.KEYCODE_Z to (0.86f to 0.92f),     // tiarap
        KeyEvent.KEYCODE_F to (0.50f to 0.85f),     // ambil item
    )
}
